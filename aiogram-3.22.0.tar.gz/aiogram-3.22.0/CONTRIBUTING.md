Please read the [Contributing](https://docs.aiogram.dev/en/dev-3.x/contributing.html) guidelines in the documentation site.
